<?php

/* Config options */

$host="localhost";
$mysql_db = "br"; 
$mysql_u = "root";
$mysql_p =  "";

 $con=mysqli_connect("$host","$mysql_u","$mysql_p","$mysql_db");
?>