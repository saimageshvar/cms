<?php
  	$host="localhost";
	$mysql_db = "ksite"; 
	$mysql_u = "root";
	$mysql_p =  "";
 	$con=mysqli_connect("$host","$mysql_u","$mysql_p","$mysql_db");
 ?>
