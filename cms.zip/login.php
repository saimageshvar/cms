<br>
<br>
<div class="row">
	<div class="col-md-4"></div>
	<div class="col-md-4">				
		<form action="index.php" method="POST">
		        <div class="form-group">
		          <input type="email" class="form-control" id="email" name="email" placeholder="Email">
		        </div>
		        <div class="form-group">
		          <input type="password" class="form-control" id="password" name="password" placeholder="Password">
		        </div>
		        <center>
		        <input type="submit" class="btn btn-default" value="Login">
		        </center>
		</form>
	</div>
	<div class="col-md-4"></div>
</div>